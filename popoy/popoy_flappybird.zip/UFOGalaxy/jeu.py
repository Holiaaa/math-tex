import pygame

pygame.init()
screen = pygame.display.set_mode((1200,720))

clock = pygame.time.Clock()

## Initialisation

## Fin initialisation

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            raise SystemExit

    screen.fill("cyan")

    ## Logique du code

    ## Fin logique

    pygame.display.flip()
    clock.tick(60)