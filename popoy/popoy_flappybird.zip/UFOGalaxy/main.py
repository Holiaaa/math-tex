import pygame
import random

# FlappyBird Remake in Python

class Tuyau:
    def __init__(self, x, y, h):
        self.x = x
        self.y = y
        self.h = h
        self.rect = pygame.Rect(x, y, 50, h)
        self.score_compte = False

pygame.init()
pygame.mixer.init()

screen = pygame.display.set_mode((1200,720))

clock = pygame.time.Clock()

font = pygame.font.Font(None, 72)

score_sound = pygame.mixer.Sound("score.wav")
crash_sound = pygame.mixer.Sound("crash.wav")
crash_played = False

x = 130
y = 60
y_speed = 1

player = pygame.Rect(x, y, 10, 10)

game_over = False
game_over_text = font.render("Game Over!", True, "red")

score = 0
score_text = font.render(str(score), True, "white")
dans_un_tuyau = False

tuyaux: list[Tuyau] = []

for i in range(1,5):
    hauteur_random = random.randint(200, 600)
    h_tuyau = 720-hauteur_random
    x_tuyau = i*300
    tuyaux.append(Tuyau(x_tuyau, hauteur_random, h_tuyau))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            raise SystemExit
        if event.type == pygame.KEYDOWN:
            if not game_over:
                if event.key == pygame.K_SPACE:
                    y_speed = -7
            else:
                if event.key == pygame.K_SPACE:
                    y_speed = 1
                    y = 60
                    tuyaux = []
                    for i in range(1,5):
                        hauteur_random = random.randint(200, 600)
                        h_tuyau = 720-hauteur_random
                        x_tuyau = i*300
                        tuyaux.append(Tuyau(x_tuyau, hauteur_random, h_tuyau))
                    score = 0
                    score_text = font.render(str(score), True, "white")
                    dans_un_tuyau = False
                    crash_played = False
                    game_over = False

    y = y + y_speed
    y_speed += 0.5

    screen.fill("cyan")
    player = pygame.Rect(x, y, 30, 30)
    pygame.draw.rect(screen, "blue", player)

    for tuyau in tuyaux:
        if not game_over:
            tuyau.x -= 3
        tuyau.rect = pygame.Rect(tuyau.x, tuyau.y, 50, tuyau.h)
        pygame.draw.rect(screen, "green", tuyau.rect)

        tuyau_en_haut = pygame.Rect(tuyau.x, 0, 50, tuyau.y-150)
        pygame.draw.rect(screen, "green", tuyau_en_haut)

        zone_de_score = pygame.Rect(tuyau.x+10, tuyau.y-150, 30, 150)
        surface = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        pygame.draw.rect(surface, (0,0,0,0), zone_de_score)
        screen.blit(surface, (0, 0))

        if tuyau.x < -20:
            tuyau.x = 1200
            tuyau.y = random.randint(200, 600)
            tuyau.h = 720-tuyau.y      
            tuyau.score_compte = False

        if player.colliderect(tuyau.rect):
            game_over = True
            if not crash_played:
                crash_sound.play()
                crash_played = True

        if player.colliderect(tuyau_en_haut):
            game_over = True
            if not crash_played:
                crash_sound.play()
                crash_played = True

        if not tuyau.score_compte and player.left > tuyau.x:
            score += 1
            tuyau.score_compte = True
            score_sound.play()

    if y > 740:
        # uniquement si restart
        #y = 60
        #y_speed = 1
        game_over = True

    if y < 0:
        y = 0

    score_text = font.render(str(score), True, "white")
    screen.blit(score_text, ((1200/2)-score_text.get_width()/2, 100-score_text.get_height()/2))

    if game_over:
        screen.blit(game_over_text, ((1200/2)-game_over_text.get_width()/2, 720/2-game_over_text.get_height()/2))

    pygame.display.flip()
    clock.tick(60)